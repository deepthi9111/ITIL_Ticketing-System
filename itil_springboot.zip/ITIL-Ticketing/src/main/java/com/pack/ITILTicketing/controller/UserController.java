package com.pack.ITILTicketing.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.ITILTicketing.dao.TicketRepository;
import com.pack.ITILTicketing.dao.UserRepository;
import com.pack.ITILTicketing.model.Ticket;
import com.sun.istack.logging.Logger;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/itil/user")
public class UserController 
{
	private Logger log=Logger.getLogger(UserController.class);
	
	@Autowired
	UserRepository userRepo;
	
	@Autowired
	TicketRepository ticketRepo;
	
	@GetMapping(value = "/uallissues/{userid}")
	public ResponseEntity<List<Ticket>> showAllUIssues(@PathVariable("userid") Integer userid)
	{
		log.info("To show all the issues to User");
		
		try 
		{
			List<Ticket> allTickets=new ArrayList<Ticket>();
			
			Iterable<Ticket> findAll = ticketRepo.findAll();
			log.info("Fetching all the issues from DB");
			
			log.info("Adding the ticket if the issue has raised by the User "+userid);
			for(Ticket t:findAll)
			{
				if(t.getUserid().intValue()==userid.intValue())
				{
					allTickets.add(t);
				}
			}
			
			if(allTickets.isEmpty())
			{
				log.info("Returning no_content status as the list is empty");
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			
			log.info("Returning the Issues list");
			return new ResponseEntity<>(allTickets, HttpStatus.OK);
		} 
		catch (Exception e) 
		{
			log.warning("Exception raised : "+e);
			
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}		
	}
	
	@PostMapping(value = "/uraise")
	public ResponseEntity<Ticket> raiseUTicket(@RequestBody Ticket ticket)
	{
		log.info("Raising a ticket");
		
		Ticket ticketToDB=new Ticket();
		
		LocalDateTime issuetime = LocalDateTime.now();
		
		ticketToDB.setUserid(ticket.getUserid());
		ticketToDB.setIssuetype(ticket.getIssuetype());
		ticketToDB.setDescription(ticket.getDescription());
		ticketToDB.setPriority(ticket.getPriority());
		ticketToDB.setVnet(ticket.getVnet());
		ticketToDB.setFno(ticket.getFno());
		ticketToDB.setContact(ticket.getContact());
		ticketToDB.setIssuetime(issuetime);
		ticketToDB.setAprvstatus("Pending");
		ticketToDB.setRejmsg("-");
		ticketToDB.setResstatus("-");
		ticketToDB.setFeedback("-");
		ticketToDB.setGid(0);
		ticketToDB.setTid(0);
		
		try
		{
			Ticket savedTicket = ticketRepo.save(ticketToDB);
			
			log.info("Issue has raised");
			return new ResponseEntity<>(savedTicket, HttpStatus.CREATED);
		}
		catch(Exception e)
		{
			log.warning("Exception raised : "+e);
			return new ResponseEntity<>(null, HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	@GetMapping(value = "/upendingissues/{userid}")
	public ResponseEntity<List<Ticket>> showUPendingIssues(@PathVariable("userid") Integer userid)
	{
		log.info("To show the pending issues to User");
		
		List<Ticket> pendingTickets=new ArrayList<Ticket>();
		
		Iterable<Ticket> findAll = ticketRepo.findAll();
		log.info("Fetching all the issues from DB");
		
		log.info("Adding the tickets to the list if the issue has raised by "+userid+" and if approved status or resolved status is Pending");
		for(Ticket t: findAll)
		{
			if((t.getUserid().intValue()==userid.intValue() && t.getAprvstatus().equals("Approved") && t.getResstatus()!=null && t.getResstatus().equals("Pending"))||
					(t.getUserid().intValue()==userid.intValue() && t.getAprvstatus().equals("Pending")))
			{
				pendingTickets.add(t);
			}
		}
		
		log.info("Returning the Pending Issues list");
		return new ResponseEntity<>(pendingTickets,HttpStatus.OK);
	}
	
	@GetMapping(value = "/uresolvedIssues/{userid}")
	public ResponseEntity<List<Ticket>> showUResolvedIssues(@PathVariable("userid") Integer userid)
	{
		log.info("To show the resolved issues to User");
		
		List<Ticket> resolvedTickets=new ArrayList<Ticket>();
		
		Iterable<Ticket> findAll = ticketRepo.findAll();
		log.info("Fetching all the issues from DB");
		
		log.info("Adding the tickets if the issues has raised by "+userid+" and resolved");
		for(Ticket t: findAll)
		{
			if(t.getUserid().intValue()==userid.intValue() && t.getAprvstatus()!="-" && t.getAprvstatus().equals("Approved") && t.getResstatus()!="-" && t.getResstatus().equals("Resolved"))
			{
				resolvedTickets.add(t);
			}
		}
		
		return new ResponseEntity<>(resolvedTickets,HttpStatus.OK);
	}
	
	@PutMapping(value = "/ugivefeedback/{ticketid}/{feedback}")
	public ResponseEntity<Ticket> uGiveFeedback(@PathVariable("ticketid") Integer ticketId, @PathVariable("feedback") String feedback)
	{
		log.info("Giving feedback");
		
		Ticket ticket = ticketRepo.findById(ticketId).get();
		
		ticket.setFeedback(feedback);
		
		Ticket savedTicket = ticketRepo.save(ticket);
		
		log.info("Feedback has submitted");
		return new ResponseEntity<>(savedTicket, HttpStatus.OK);
	}
}
