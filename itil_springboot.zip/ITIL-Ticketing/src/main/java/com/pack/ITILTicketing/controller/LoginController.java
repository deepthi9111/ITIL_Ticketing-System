package com.pack.ITILTicketing.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.ITILTicketing.dao.GateKeeperRepository;
import com.pack.ITILTicketing.dao.TeamRepository;
import com.pack.ITILTicketing.dao.UserRepository;
import com.pack.ITILTicketing.model.GateKeeper;
import com.pack.ITILTicketing.model.Login;
import com.pack.ITILTicketing.model.Password;
import com.pack.ITILTicketing.model.Team;
import com.pack.ITILTicketing.model.User;
import com.sun.istack.logging.Logger;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/itil")
public class LoginController 
{
	
	private Logger log=Logger.getLogger(LoginController.class);
	
	@Autowired
	private GateKeeperRepository gateKeeperRepo;
	
	@Autowired
	private TeamRepository teamRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@PostMapping(value = "/login")
	public ResponseEntity<Object> checkLogin(@RequestBody Login login)
	{
		log.info("In checkLogin() method to check the credentials");
		
		if(login.getTypeofuser().contentEquals("gatekeeper"))
		{
			
			log.info("Credentials checking for the type Gatekeeper");
			
			GateKeeper gateKeeperDB = gateKeeperRepo.findById(login.getUserid()).get();
			
			if(gateKeeperDB.getPassword().contentEquals(login.getPassword()))
			{
				log.info("Credentials are valid");
				
				return new ResponseEntity<>(gateKeeperDB,HttpStatus.OK);
			}
			else
			{
				log.warning("Credentials are invalid");
				
				return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
			}
		}
		else if(login.getTypeofuser().contentEquals("team"))
		{
			log.info("Credentials checking for the type Team");
			
			Team teamDB = teamRepo.findById(login.getUserid()).get();
			
			if(teamDB.getPassword().contentEquals(login.getPassword()))
			{
				log.info("Credentials are valid");
				
				return new ResponseEntity<>(teamDB,HttpStatus.OK);
			}
			else
			{
				log.warning("Credentials are invalid");
				
				return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
			}
		}
		else
		{
			log.info("Credentials checking for the type User");
			
			User userDB = userRepo.findById(login.getUserid()).get();
			
			if(userDB.getPassword().contentEquals(login.getPassword()))
			{
				log.info("Credentials are valid");
				
				return new ResponseEntity<>(userDB,HttpStatus.OK);
			}
			else
			{
				log.warning("Credentials are invalid");
				
				return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
			}
		}
	}
	
	@PutMapping(value = "/changePassword/{id}/{typeofuser}")
	public ResponseEntity<Object> changePassword(@RequestBody Password password, @PathVariable("id") Integer id, @PathVariable("typeofuser") String typeofuser)
	{
		log.info("In changePassword() method");
		
		System.out.println("hello "+id+" "+typeofuser);
		if(typeofuser.contentEquals("gatekeeper"))
		{
			log.info("To change the password of the type Gatekeeper");
			
			GateKeeper gateKeeperDB = gateKeeperRepo.findById(id).get();
			
			if(gateKeeperDB.getPassword().equals(password.getOldPassword()))
			{
				gateKeeperDB.setPassword(password.getNewPassword());
				GateKeeper save = gateKeeperRepo.save(gateKeeperDB);
				
				log.info("Password has updated");
				
				return new ResponseEntity<>(save,HttpStatus.OK);
			}
			else
			{
				log.warning("Error occurred while changing the password");
				
				return new ResponseEntity<>(null,HttpStatus.EXPECTATION_FAILED);
			}
		}
		else if(typeofuser.contentEquals("team"))
		{
			log.info("To change the password of the type Team");
			
			Team teamDB = teamRepo.findById(id).get();
			
			if(teamDB.getPassword().equals(password.getOldPassword()))
			{
				teamDB.setPassword(password.getNewPassword());
				Team save = teamRepo.save(teamDB);
				
				log.info("Password has updated");
				
				return new ResponseEntity<>(save,HttpStatus.OK);
			}
			else
			{
				log.warning("Error occurred while changing the password");
				
				return new ResponseEntity<>(null,HttpStatus.EXPECTATION_FAILED);
			}
		}
		else
		{
			log.info("To change the password of the type User");
			
			User userDB = userRepo.findById(id).get();
			
			if(userDB.getPassword().equals(password.getOldPassword()))
			{
				userDB.setPassword(password.getNewPassword());
				User save = userRepo.save(userDB);
				
				log.info("Password has updated");
				
				return new ResponseEntity<>(save,HttpStatus.OK);
			}
			else
			{
				log.warning("Error occurred while changing the password");
				
				return new ResponseEntity<>(null,HttpStatus.EXPECTATION_FAILED);
			}
		}
	}

	@GetMapping(value = "/profile/{id}/{typeofuser}")
	public ResponseEntity<Object> getProfile(@PathVariable("id") Integer id, @PathVariable("typeofuser") String typeofuser) 
	{
		log.info("Viewing the profile");
		
		if (typeofuser.contentEquals("gatekeeper")) 
		{
			log.info("Profile of Gatekeeper");
			
			GateKeeper gateKeeperDB = gateKeeperRepo.findById(id).get();

			return new ResponseEntity<>(gateKeeperDB, HttpStatus.OK);
		}
		
		else if(typeofuser.contentEquals("team"))
		{
			log.info("Profile of Team");
			
			Team teamDB = teamRepo.findById(id).get();
			return new ResponseEntity<>(teamDB,HttpStatus.OK);
		}
		else
		{
			log.info("Profile of User");
			
			User userDB = userRepo.findById(id).get();
			return new ResponseEntity<>(userDB,HttpStatus.OK);
		}

	}

}
