package com.pack.ITILTicketing.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.ITILTicketing.dao.TicketRepository;
import com.pack.ITILTicketing.model.Ticket;
import com.sun.istack.logging.Logger;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/itil/team")
public class TeamController 
{
	private Logger log=Logger.getLogger(TeamController.class);
	
	@Autowired
	TicketRepository ticketRepo;
	
	@GetMapping(value = "/tresolvedissues/{tid}")
	public ResponseEntity<List<Ticket>> showTResolvedIssues(@PathVariable("tid") Integer tid)
	{
		log.info("To show all the Resolved Issues to Team member");
		
		List<Ticket> resolvedTickets=new ArrayList<Ticket>();
		
		Iterable<Ticket> findAll = ticketRepo.findAll();
		log.info("Fetching all the issues from DB");
		
		log.info("Adding the tickets to the list if the issue has resolved by the team member "+tid);
		for(Ticket t: findAll)
		{
			if(t.getAprvstatus()!=null && t.getAprvstatus().equals("Approved") && t.getResstatus()!=null && t.getResstatus().equals("Resolved") && t.getTid().intValue()==tid.intValue())
			{
				resolvedTickets.add(t);
			}
		}
		
		log.info("Returning the Resolved Issues list");
		return new ResponseEntity<>(resolvedTickets,HttpStatus.OK);
	}
	
	@GetMapping(value = "/tpendingissues/{tid}")
	public ResponseEntity<List<Ticket>> showTPendingIssues(@PathVariable("tid") Integer tid)
	{
		log.info("To show all the Pending Issues to Team member");
		
		List<Ticket> pendingTickets=new ArrayList<Ticket>();
		
		Iterable<Ticket> findAll = ticketRepo.findAll();
		log.info("Fetching all the issues from DB");
		
		log.info("Adding the tickets to the list if the issue has not resolved yet which is assigned to the team member "+tid);		
		for(Ticket t: findAll)
		{
			if(t.getAprvstatus()!=null && t.getAprvstatus().equals("Approved") && t.getResstatus()!=null && t.getResstatus().equals("Pending") && t.getTid().intValue()==tid.intValue())
			{
				pendingTickets.add(t);
			}
		}
		
		log.info("Returning the Pending Issues list");
		return new ResponseEntity<>(pendingTickets,HttpStatus.OK);
	}
	
	@GetMapping(value = "/tallissues/{tid}")
	public ResponseEntity<List<Ticket>> showTAllIssues(@PathVariable("tid") Integer tid)
	{
		log.info("To show all the Issues to Team member");
		
		List<Ticket> allTickets=new ArrayList<Ticket>();
		
		Iterable<Ticket> findAll = ticketRepo.findAll();
		log.info("Fetching all the issues from DB");
		
		log.info("Adding the tickets to the list if the team member id of the ticket matches with login id");
		for(Ticket t: findAll)
		{
			if(t.getTid().intValue()==tid.intValue())
			{
				allTickets.add(t);
			}
		}
		
		log.info("Returning the issues list");
		return new ResponseEntity<>(allTickets,HttpStatus.OK);
	}
	
	@PutMapping(value = "/tresolveissue/{ticketid}")
	public ResponseEntity<Ticket> tToResolveIssue(@PathVariable("ticketid") Integer ticketId)
	{
		log.info("Resolving the issue");
		
		try 
		{
			Ticket ticket = ticketRepo.findById(ticketId).get();	
			
			LocalDateTime restime = LocalDateTime.now();
			ticket.setResstatus("Resolved");
			ticket.setRestime(restime);
			ticket.setFeedback("Yet to give");
			
			Ticket savedTicket = ticketRepo.save(ticket);
			
			log.info("Issue has resolved by the team member "+savedTicket.getTid());
			return new ResponseEntity<>(savedTicket,HttpStatus.OK);
		} 
		catch (Exception e) 
		{
			log.warning("Exception raised : "+e);
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}
	}
}
