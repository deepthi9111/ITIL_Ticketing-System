package com.pack.ITILTicketing.dao;

import org.springframework.data.repository.CrudRepository;

import com.pack.ITILTicketing.model.User;

public interface UserRepository extends CrudRepository<User, Integer>
{

}
