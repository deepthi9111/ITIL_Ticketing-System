package com.pack.ITILTicketing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItilTicketingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ItilTicketingApplication.class, args);
	}

}
