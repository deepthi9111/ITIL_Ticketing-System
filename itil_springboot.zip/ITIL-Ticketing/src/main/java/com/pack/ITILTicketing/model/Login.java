package com.pack.ITILTicketing.model;

public class Login 
{
	private int userid;
	private String password;
	private String typeofuser;
	
	public Login() 
	{
		super();
	}
	
	public Login(int userid, String password, String typeofuser) 
	{
		super();
		this.userid = userid;
		this.password = password;
		this.typeofuser = typeofuser;
	}

	public int getUserid() 
	{
		return userid;
	}

	public void setUserid(int userid) 
	{
		this.userid = userid;
	}

	public String getPassword() 
	{
		return password;
	}

	public void setPassword(String password) 
	{
		this.password = password;
	}

	public String getTypeofuser() 
	{
		return typeofuser;
	}

	public void setTypeofuser(String typeofuser) 
	{
		this.typeofuser = typeofuser;
	}

	@Override
	public String toString() 
	{
		return "Login [userid=" + userid + ", password=" + password + ", typeofuser=" + typeofuser + "]";
	}
	
	
}
