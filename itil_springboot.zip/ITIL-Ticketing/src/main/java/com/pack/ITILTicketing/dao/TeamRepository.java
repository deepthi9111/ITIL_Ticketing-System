package com.pack.ITILTicketing.dao;

import org.springframework.data.repository.CrudRepository;

import com.pack.ITILTicketing.model.Team;

public interface TeamRepository extends CrudRepository<Team, Integer>
{

}
