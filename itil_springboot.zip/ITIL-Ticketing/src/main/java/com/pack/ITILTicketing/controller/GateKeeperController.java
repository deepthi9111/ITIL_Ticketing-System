package com.pack.ITILTicketing.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.ITILTicketing.dao.GateKeeperRepository;
import com.pack.ITILTicketing.dao.TeamRepository;
import com.pack.ITILTicketing.dao.TicketRepository;
import com.pack.ITILTicketing.model.Team;
import com.pack.ITILTicketing.model.Ticket;
import com.sun.istack.logging.Logger;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/itil/gatekeeper")
public class GateKeeperController 
{
	private Logger log=Logger.getLogger(GateKeeperController.class);
	
	@Autowired
	GateKeeperRepository gatekeeperRepo;
	
	@Autowired
	TicketRepository ticketRepo;
	
	@Autowired
	TeamRepository teamRepo;
	
	@GetMapping(value = "/gallissues/{gid}")
	public ResponseEntity<List<Ticket>> showAllGIssues(@PathVariable("gid") Integer gid)
	{
		log.info("To show all the issues to Gatekeeper");
		
		try 
		{
			List<Ticket> allTickets=new ArrayList<Ticket>();
			
			Iterable<Ticket> findAll = ticketRepo.findAll();
			log.info("Fetching all the tickets from DB");
			
			log.info("Adding the tickets to the list if the Gatekeeper id matches with login id");
			for(Ticket t:findAll)
			{
				if(t.getGid().intValue()==gid.intValue())
				{
					allTickets.add(t);
				}
			}
			
			if(allTickets.isEmpty())
			{
				log.info("Returning no_content status as the list is empty");
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			
			log.info("Returning the Issues list");
			return new ResponseEntity<>(allTickets, HttpStatus.OK);
			
		} 
		catch (Exception e) 
		{
			log.warning("Exception raised : "+e);
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}		
	}
	
	@GetMapping(value = "/gpendingissues")
	public ResponseEntity<List<Ticket>> showAllGPendingIssues()
	{
		log.info("To show all the pending issues to Gatekeeper");
		
		try 
		{
			List<Ticket> pendingTickets=new ArrayList<Ticket>();
			
			Iterable<Ticket> findAll = ticketRepo.findAll();
			log.info("Fetching all the tickets from DB");
			
			log.info("Adding the tickets to the list if the issue has not approved or rejected yet");
			for(Ticket t:findAll)
			{
				if(t.getAprvstatus().equals("Pending"))
				{
					pendingTickets.add(t);
				}
			}
			
			if(pendingTickets.isEmpty())
			{
				log.info("Returning no_content status as the list is empty");
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			
			log.info("Returning the Pending Issues list");
			return new ResponseEntity<>(pendingTickets, HttpStatus.OK);
		} 
		catch (Exception e) 
		{
			log.warning("Exception raised : "+e);
			
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}		
	}
	
	@GetMapping(value = "/gtoapprove/{ticketid}")
	public ResponseEntity<List<Integer>> gToApproveIssues(@PathVariable("ticketid") Integer ticketId)
	{
		log.info("Sending the team member ids to Gatekeeper to assign the issue");
		
		List<Integer> teamIds=new ArrayList<Integer>();
		
		Ticket ticket = ticketRepo.findById(ticketId).get();
		
		Iterable<Team> team = teamRepo.findAll();
		log.info("Fetching all the team members");
		
		log.info("Adding the team id if the specialization of team member matches with issue type ");
		for(Team t:team)
		{
			if(t.getSpecialization().equalsIgnoreCase(ticket.getIssuetype()))
			{
				teamIds.add(t.getTid());
			}
		}
		
		log.info("Returning the Team member Ids list");
		return new ResponseEntity<>(teamIds,HttpStatus.OK);
	}
	
	@PutMapping(value = "/ggetapprove/{ticketid}/{gid}/{tid}")
	public ResponseEntity<Ticket> gGetApprove(@PathVariable("tid") Integer tid, @PathVariable("ticketid") Integer ticketid, @PathVariable("gid") Integer gid)
	{
		log.info("Assigning the issue to the team member");
		
		try 
		{
			LocalDateTime aprvrejtime = LocalDateTime.now();
			
			Ticket ticket = ticketRepo.findById(ticketid).get();
			
			ticket.setAprvstatus("Approved");
			ticket.setGid(gid);
			ticket.setAprvrejtime(aprvrejtime);
			ticket.setTid(tid);
			ticket.setResstatus("Pending");
			
			Ticket savedTicket = ticketRepo.save(ticket);
			
			log.info("Issue is approved by the Gatekeeper "+gid);
			log.info("Assigned the issue to the team member with id "+tid);
			return new ResponseEntity<>(savedTicket,HttpStatus.OK);
			
		} 
		catch (Exception e) 
		{
			log.warning("Exception raised : "+e);
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	@PutMapping(value = "/ggetreject/{ticketid}/{gid}/{rejmsg}")
	public ResponseEntity<Ticket> gGetReject(@PathVariable("rejmsg") String rejmsg, @PathVariable("ticketid") Integer ticketid, @PathVariable("gid") Integer gid)
	{
		log.info("Rejecting the issue");
		
		try 
		{
			LocalDateTime aprvrejtime=LocalDateTime.now();
			
			Ticket ticket = ticketRepo.findById(ticketid).get();
			
			ticket.setAprvstatus("Rejected");
			ticket.setRejmsg(rejmsg);
			ticket.setGid(gid);
			ticket.setAprvrejtime(aprvrejtime);
			
			Ticket savedTicket = ticketRepo.save(ticket);
			
			log.info("Issue is rejected by the Gatekeeper "+gid);
			log.info("Rejected the issue because : "+rejmsg);
			return new ResponseEntity<>(savedTicket,HttpStatus.OK);
		} 
		catch (Exception e) 
		{
			log.warning("Exception raised : "+e);
			return new ResponseEntity<>(HttpStatus.EXPECTATION_FAILED);
		}
	}
	
	@GetMapping(value = "/gresolvedissues/{gid}")
	public ResponseEntity<List<Ticket>> showGResolvedIssues(@PathVariable("gid") Integer gid)
	{
		log.info("To show all the resolved issues to Gatekeeper");
		
		List<Ticket> resolvedTickets=new ArrayList<Ticket>();
		
		Iterable<Ticket> findAll = ticketRepo.findAll();
		log.info("Fetching all the tickets from DB");
		
		log.info("Adding the tickets to the list if the issue has approved by the Gatekeeper "+gid+" and the issue has resolved");
		for(Ticket t: findAll)
		{
			if(t.getGid().intValue()==gid.intValue() && t.getAprvstatus()!=null && t.getAprvstatus().equals("Approved")  && t.getResstatus()!=null && t.getResstatus().equals("Resolved"))
			{
				resolvedTickets.add(t);
			}
		}
		
		log.info("Returning the Resolved Issues list");
		return new ResponseEntity<>(resolvedTickets, HttpStatus.OK);
	}
}
