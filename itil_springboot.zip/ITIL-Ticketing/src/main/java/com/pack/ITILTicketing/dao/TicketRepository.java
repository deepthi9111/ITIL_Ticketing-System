package com.pack.ITILTicketing.dao;

import org.springframework.data.repository.CrudRepository;

import com.pack.ITILTicketing.model.Ticket;

public interface TicketRepository extends CrudRepository<Ticket, Integer>
{

}
