package com.pack.ITILTicketing.model;

import java.sql.Date;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table (name="ticket")
public class Ticket 
{
	@Id
	@GeneratedValue (strategy = GenerationType.AUTO)
	private Integer ticketid;
	private Integer userid;
	private String issuetype;
	private String description;
	private Integer priority;
	private String vnet;
	private Integer fno;
	private long contact;
	private LocalDateTime issuetime;
	private String aprvstatus;
	private String rejmsg;
	private Integer gid;
	private LocalDateTime aprvrejtime;
	private Integer tid;
	private String resstatus;
	private LocalDateTime restime;
	private String feedback;
	
	public Ticket() 
	{
		super();
	}

	public Ticket(Integer ticketid, Integer userid, String issuetype, String description, Integer priority, String vnet,
			Integer fno, long contact, LocalDateTime issuetime, String aprvstatus, String rejmsg, Integer gid, LocalDateTime aprvrejtime,
			Integer tid, String resstatus, LocalDateTime restime, String feedback) 
	{
		super();
		this.ticketid = ticketid;
		this.userid = userid;
		this.issuetype = issuetype;
		this.description = description;
		this.priority = priority;
		this.vnet = vnet;
		this.fno = fno;
		this.contact = contact;
		this.issuetime = issuetime;
		this.aprvstatus = aprvstatus;
		this.rejmsg = rejmsg;
		this.gid = gid;
		this.aprvrejtime = aprvrejtime;
		this.tid = tid;
		this.resstatus = resstatus;
		this.restime = restime;
		this.feedback = feedback;
	}

	public Integer getTicketid() {
		return ticketid;
	}

	public void setTicketid(Integer ticketid) {
		this.ticketid = ticketid;
	}

	public Integer getUserid() {
		return userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getIssuetype() {
		return issuetype;
	}

	public void setIssuetype(String issuetype) {
		this.issuetype = issuetype;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public String getVnet() {
		return vnet;
	}

	public void setVnet(String vnet) {
		this.vnet = vnet;
	}

	public Integer getFno() {
		return fno;
	}

	public void setFno(Integer fno) {
		this.fno = fno;
	}

	public long getContact() {
		return contact;
	}

	public void setContact(long contact) {
		this.contact = contact;
	}

	public LocalDateTime getIssuetime() {
		return issuetime;
	}

	public void setIssuetime(LocalDateTime issuetime) {
		this.issuetime = issuetime;
	}

	public String getAprvstatus() {
		return aprvstatus;
	}

	public void setAprvstatus(String aprvstatus) {
		this.aprvstatus = aprvstatus;
	}

	public String getRejmsg() {
		return rejmsg;
	}

	public void setRejmsg(String rejmsg) {
		this.rejmsg = rejmsg;
	}

	public Integer getGid() {
		return gid;
	}

	public void setGid(Integer gid) {
		this.gid = gid;
	}

	public LocalDateTime getAprvrejtime() {
		return aprvrejtime;
	}

	public void setAprvrejtime(LocalDateTime aprvrejtime) {
		this.aprvrejtime = aprvrejtime;
	}

	public Integer getTid() {
		return tid;
	}

	public void setTid(Integer tid) {
		this.tid = tid;
	}

	public String getResstatus() {
		return resstatus;
	}

	public void setResstatus(String resstatus) {
		this.resstatus = resstatus;
	}

	public LocalDateTime getRestime() {
		return restime;
	}

	public void setRestime(LocalDateTime restime) {
		this.restime = restime;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	@Override
	public String toString() 
	{
		return "Ticket [ticketid=" + ticketid + ", userid=" + userid + ", issuetype=" + issuetype + ", description="
				+ description + ", priority=" + priority + ", vnet=" + vnet + ", fno=" + fno + ", contact=" + contact
				+ ", issuetime=" + issuetime + ", aprvstatus=" + aprvstatus + ", rejmsg=" + rejmsg + ", gid=" + gid
				+ ", aprvrejtime=" + aprvrejtime + ", tid=" + tid + ", resstatus=" + resstatus + ", restime=" + restime
				+ ", feedback=" + feedback + "]";
	}
	
	
}
