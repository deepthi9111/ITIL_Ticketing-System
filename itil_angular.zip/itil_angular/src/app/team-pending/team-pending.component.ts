import { Component, OnInit } from '@angular/core';
import { TeamService } from '../team.service';
import { Ticket } from '../ticket';
import { Router } from '@angular/router';

@Component({
  selector: 'app-team-pending',
  templateUrl: './team-pending.component.html',
  styleUrls: ['./team-pending.component.css']
})
export class TeamPendingComponent implements OnInit {

  constructor(private teamService:TeamService, private router:Router) { }

  userid=sessionStorage.getItem('userid');

  tickets:Ticket[];
  submitted=false;

  p:number=1;
  count:number=3;

  ngOnInit(): void 
  {
    this.loadTPendingIssues();
  }

  loadTPendingIssues()
  {
    this.tickets=[];
    this.teamService.showTPendingIssues()
    .subscribe(data=>
      {
        console.log(data);
        this.tickets=data;
        this.submitted=true;
      },error=>console.log(error));
  }

  toResolve(ticketid)
  {
    sessionStorage.setItem('ticketid',ticketid);
    this.teamService.toResolveIssue(ticketid).subscribe(data=>
      {
        console.log(data);
        this.router.navigate(['tres']);
      })
  }
}
