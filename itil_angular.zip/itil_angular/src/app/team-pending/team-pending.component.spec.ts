import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeamPendingComponent } from './team-pending.component';

describe('TeamPendingComponent', () => {
  let component: TeamPendingComponent;
  let fixture: ComponentFixture<TeamPendingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TeamPendingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TeamPendingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
