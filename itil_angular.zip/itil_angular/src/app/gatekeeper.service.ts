import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GatekeeperService 
{
   
  constructor(private http:HttpClient) { }

  private baseUrl='http://localhost:8080/itil/gatekeeper';

  userid;

  ticketid;

  tid;

  rejmsg;

  showAllIssues():Observable<any> 
  {
    console.log(this.userid);
    this.userid=sessionStorage.getItem('userid');
    return this.http.get(`${this.baseUrl}/gallissues/${this.userid}`);
  }

  showPendingIssues():Observable<any>
  {
    return this.http.get(`${this.baseUrl}/gpendingissues`)
  }

  toRejectIssue(ticketid: any):Observable<any>
  {
    console.log(ticketid);
    return this.http.get(`${this.baseUrl}/gtoreject`,ticketid);
  }

  getRejectIssue(rejmsg: any):Observable<any>
  {
    this.rejmsg=rejmsg;
    this.ticketid=sessionStorage.getItem('ticketid');
    this.userid=sessionStorage.getItem('userid');

    return this.http.put(`${this.baseUrl}/ggetreject/${this.ticketid}/${this.userid}/${this.rejmsg}`,rejmsg);
  }

  toApproveIssue(ticketid: any) :Observable<any>
  {
    console.log(ticketid);
    this.ticketid=ticketid;
    return this.http.get(`${this.baseUrl}/gtoapprove/${this.ticketid}`);
  }
  
  getApproveIssue(tid: any) :Observable<any>
  {
    this.tid=tid;
    this.ticketid=sessionStorage.getItem('ticketid');
    this.userid=sessionStorage.getItem('userid');
    return this.http.put(`${this.baseUrl}/ggetapprove/${this.ticketid}/${this.userid}/${tid}`,tid);
  }

  showAllResolvedIssues(): Observable<any>
  {
    this.userid=sessionStorage.getItem('userid');
    return this.http.get(`${this.baseUrl}/gresolvedissues/${this.userid}`);
  }
}
