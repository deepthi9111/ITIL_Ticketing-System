export class Profile
{
    id;
    name;
    email;
}