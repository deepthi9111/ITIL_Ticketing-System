export class ChangePassword
{
    oldPassword;
    newPassword;
    confirmPassword;
}