import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TeamService 
{

  constructor(private http:HttpClient) { }

  private baseUrl='http://localhost:8080/itil/team';

  userid;

  ticketid;
  
  showTResolvedIssues():Observable<any>
  {
    this.userid=sessionStorage.getItem('userid');
    return this.http.get(`${this.baseUrl}/tresolvedissues/${this.userid}`);
  }

  showTPendingIssues(): Observable<any>
  {
    this.userid=sessionStorage.getItem('userid');
    return this.http.get(`${this.baseUrl}/tpendingissues/${this.userid}`);
  }

  showTAllIssues():Observable<any>
  {
    this.userid=sessionStorage.getItem('userid');
    return this.http.get(`${this.baseUrl}/tallissues/${this.userid}`);
  }

  toResolveIssue(ticketid: any):Observable<any>
  {
    this.ticketid=sessionStorage.getItem('ticketid');
    return this.http.put(`${this.baseUrl}/tresolveissue/${this.ticketid}`,this.ticketid);
  }
}
