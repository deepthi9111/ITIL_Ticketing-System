export class Credentials
{
    userid:number;
    password:string;
    typeofuser:string;
}