import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Ticket } from '../ticket';

@Component({
  selector: 'app-user-pending',
  templateUrl: './user-pending.component.html',
  styleUrls: ['./user-pending.component.css']
})
export class UserPendingComponent implements OnInit {

  constructor(private userService: UserService) { }

  userid=sessionStorage.getItem('userid');

  tickets:Ticket[];
  submitted=false;

  p:number=1;
  count:number=3;

  ngOnInit(): void 
  {
    this.loadUPendingIssues();
  }

  loadUPendingIssues()
  {
    this.tickets=[];
    this.userService.showPendingIssues()
    .subscribe(data=>
      {
        console.log(data);
        this.tickets=data;
        this.submitted=true;
      },error=>console.log(error));
  }

}
