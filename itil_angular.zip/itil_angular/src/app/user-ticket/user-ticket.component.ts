import { Component, OnInit } from '@angular/core';
import { Ticket } from '../ticket';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-ticket',
  templateUrl: './user-ticket.component.html',
  styleUrls: ['./user-ticket.component.css']
})
export class UserTicketComponent implements OnInit {

  constructor(private userService:UserService) { }

  ngOnInit(): void {
  }

  ticket:Ticket=new Ticket();
  submitted=false;

  userid=sessionStorage.getItem('userid');
  
  newTicket():void
  {
    this.submitted=false;
    this.ticket=new Ticket();
  }

  onSubmit()
  {
    this.ticket.userid=this.userid;
    this.userService.raiseTicket(this.ticket)
    .subscribe(data=>
      {
        console.log(data);
        this.submitted=true;
      },error=>console.log(error));
      this.ticket=new Ticket();
  }
}
