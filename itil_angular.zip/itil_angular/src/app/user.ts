export class User
{
    userid;
    name;
    email;
    password;
    contact;
    dob;
    doj;
}