import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {NgxPaginationModule} from 'ngx-pagination';
import {HttpClientModule} from '@angular/common/http';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './login/login.component';
import { GatekeeperComponent } from './gatekeeper/gatekeeper.component';
import { TeamComponent } from './team/team.component';
import { UserComponent } from './user/user.component';
import { LogoutComponent } from './logout/logout.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { GatekeeperPendingComponent } from './gatekeeper-pending/gatekeeper-pending.component';
import { GatekeeperResolvedComponent } from './gatekeeper-resolved/gatekeeper-resolved.component';
import { UserPendingComponent } from './user-pending/user-pending.component';
import { UserTicketComponent } from './user-ticket/user-ticket.component';
import { UserResolvedComponent } from './user-resolved/user-resolved.component';
import { TeamPendingComponent } from './team-pending/team-pending.component';
import { TeamResolvedComponent } from './team-resolved/team-resolved.component';
import { WelcomeComponent } from './welcome/welcome.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    GatekeeperComponent,
    TeamComponent,
    UserComponent,
    LogoutComponent,
    ChangePasswordComponent,
    MyProfileComponent,
    GatekeeperPendingComponent,
    GatekeeperResolvedComponent,
    UserPendingComponent,
    UserTicketComponent,
    UserResolvedComponent,
    TeamPendingComponent,
    TeamResolvedComponent,
    WelcomeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgxPaginationModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
