import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GatekeeperPendingComponent } from './gatekeeper-pending.component';

describe('GatekeeperPendingComponent', () => {
  let component: GatekeeperPendingComponent;
  let fixture: ComponentFixture<GatekeeperPendingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GatekeeperPendingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GatekeeperPendingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
