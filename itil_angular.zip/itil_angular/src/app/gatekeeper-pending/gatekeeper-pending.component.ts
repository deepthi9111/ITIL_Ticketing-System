import { Component, OnInit } from '@angular/core';
import { GatekeeperService } from '../gatekeeper.service';
import { Ticket } from '../ticket';
import { Router } from '@angular/router';

@Component({
  selector: 'app-gatekeeper-pending',
  templateUrl: './gatekeeper-pending.component.html',
  styleUrls: ['./gatekeeper-pending.component.css']
})
export class GatekeeperPendingComponent implements OnInit {

  constructor(private gatekeeperService:GatekeeperService, private router:Router) { }

  userid=sessionStorage.getItem('userid');

  tickets:Ticket[];
  submitted=false;

  teamIds:Number[];
  p:number=1;
  count:number=3;

  rejmsg;
  tid;

  ticketid:number;
  show:string;
  ngOnInit(): void 
  {
    this.show='pending';
    this.loadGPendingIssues();
  }

  loadGPendingIssues()
  {
    this.tickets=[];
    this.gatekeeperService.showPendingIssues()
    .subscribe(data=>
      {
        console.log(data);
        this.tickets=data;
        this.submitted=true;
      },error=>console.log(error));
  }

  toApprove(ticketid)
  {
    sessionStorage.setItem('ticketid',ticketid);
    this.gatekeeperService.toApproveIssue(ticketid).subscribe(data=>
      {
        this.teamIds=data;
        console.log(this.teamIds);
        this.show='approve';
      })
  }

  getApprove()
  {
    this.gatekeeperService.getApproveIssue(this.tid).subscribe(data=>
      {
        console.log(data);
        sessionStorage.removeItem('ticketid');
        this.router.navigate(['glist']);
      })
  }
  toReject(ticketid)
  {
    sessionStorage.setItem('ticketid',ticketid);
    this.show='reject';
  }

  getReject()
  {
    this.gatekeeperService.getRejectIssue(this.rejmsg).subscribe(data=>
      {
        console.log(data);
        sessionStorage.removeItem('ticketid');
        this.router.navigate(['glist']);
      })
  }
}
