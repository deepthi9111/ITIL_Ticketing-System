import { Component, OnInit, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { ChangePassword } from '../password';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChangePasswordComponent implements OnInit {

  constructor(private authService:AuthenticationService,private loginService: LoginService,private router:Router,private cd:ChangeDetectorRef) { }

  ngOnInit(): void {
  }

  password:ChangePassword=new ChangePassword();
  typeofuser=sessionStorage.getItem('typeofuser');
  errors=false;
  changed=false;
  onChange()
  {
    this.authService.changePassword(this.password).subscribe(data=>
    {
      this.errors=false;
      this.changed=true;
      this.cd.markForCheck();
    },error=>
    {
      this.errors=true;
    });
  }
  goBack()
  {
    this.changed=false;
    this.password=new ChangePassword();
  }
  refresh()
  {
    this.cd.detectChanges();
  }

}
