import { Component, OnInit } from '@angular/core';
import { TeamService } from '../team.service';
import { Ticket } from '../ticket';

@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.css']
})
export class TeamComponent implements OnInit {

  constructor(private teamService:TeamService) { }

  userid=sessionStorage.getItem('userid');

  tickets:Ticket[];
  submitted=false;

  p:number=1;
  count:number=3;

  ngOnInit(): void 
  {
    this.loadTAllIssues();
  }

  loadTAllIssues()
  {
    this.tickets=[];
    this.teamService.showTAllIssues()
    .subscribe(data=>
      {
        console.log(data);
        this.tickets=data;
        this.submitted=true;
      },error=>console.log(error));
  }

}
