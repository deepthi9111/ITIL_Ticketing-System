import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef} from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../authentication.service';
import { Credentials } from '../credentials';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent implements OnInit{

  credentials:Credentials=new Credentials();

  invalidLogin=false;

  constructor(private router:Router,
              private authService: AuthenticationService,
              private cd:ChangeDetectorRef) { }
  

  ngOnInit(): void {
  }

  checkLogin()
  {
    this.authService.authenticate(this.credentials).subscribe(data=>
    {
      console.log(data);
      console.log(data.name);
  
      sessionStorage.setItem('userid', this.credentials.userid+"");
      sessionStorage.setItem('typeofuser',this.credentials.typeofuser);
      sessionStorage.setItem('name',data.name);
        
      console.log(sessionStorage.getItem('userid'));
      console.log(sessionStorage.getItem('typeofuser'));
      this.cd.markForCheck();

      this.invalidLogin=false;

      if(this.credentials.typeofuser === 'gatekeeper')
      {
        this.router.navigate(['glist']);
      }
      else if(this.credentials.typeofuser === 'team')
      {
        this.router.navigate(['tlist']);
      }
      else
      {
        this.router.navigate(['ulist']);
      }
    },error=>
    {
      console.log(error);
      this.invalidLogin=true;
    });
 
  }

  refresh()
  {
    this.cd.detectChanges();
  }
 
}
