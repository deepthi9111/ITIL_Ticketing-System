import { Component, OnInit } from '@angular/core';
import { GatekeeperService } from '../gatekeeper.service';
import { Ticket } from '../ticket';

@Component({
  selector: 'app-gatekeeper-resolved',
  templateUrl: './gatekeeper-resolved.component.html',
  styleUrls: ['./gatekeeper-resolved.component.css']
})
export class GatekeeperResolvedComponent implements OnInit {

  constructor(private gatekeeperService: GatekeeperService) { }

  userid=sessionStorage.getItem('userid');

  tickets:Ticket[];
  submitted=false;

  p:number=1;
  count:number=3;

  ngOnInit(): void 
  {
    this.loadGResolvedIssues();
  }

  loadGResolvedIssues()
  {
    this.tickets=[];
    this.gatekeeperService.showAllResolvedIssues()
    .subscribe(data=>
      {
        console.log(data);
        this.tickets=data;
        this.submitted=true;
      },error=>console.log(error));
  }

}
