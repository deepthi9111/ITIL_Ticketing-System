import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GatekeeperResolvedComponent } from './gatekeeper-resolved.component';

describe('GatekeeperResolvedComponent', () => {
  let component: GatekeeperResolvedComponent;
  let fixture: ComponentFixture<GatekeeperResolvedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GatekeeperResolvedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GatekeeperResolvedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
