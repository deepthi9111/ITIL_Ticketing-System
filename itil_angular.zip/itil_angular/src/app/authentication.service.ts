import { Injectable, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { LoginService } from './login.service';
import { Credentials } from './credentials';
import { Observable } from 'rxjs';
import { ChangePassword } from './password';

@Injectable({
  providedIn: 'root',
  
})
export class AuthenticationService 
{
  
  constructor(private loginService: LoginService) { }

  userid:string;
  typeofuser:string;
  name:string;
  loggedin=false;
  
  changePassword(password:ChangePassword):Observable<any>
  {
    return this.loginService.changePassword(password);
  }

  authenticate(credentials:Credentials): Observable<any>
  {
    return this.loginService.checkCredentials(credentials);
  }

  viewProfile():Observable<any>
  {
    console.log(sessionStorage.getItem('userid'));
    console.log(sessionStorage.getItem('typeofuser'));
    return this.loginService.viewProfile();
  }

  isUserLoggedIn()
  {
    let user=sessionStorage.getItem('userid');
    this.userid=user;
    this.typeofuser=sessionStorage.getItem('typeofuser');
    this.name=sessionStorage.getItem('name');
    return !(user===null);
  }

  logOut()
  {
    sessionStorage.removeItem('userid');
    sessionStorage.removeItem('typeofuser');
  }
}
