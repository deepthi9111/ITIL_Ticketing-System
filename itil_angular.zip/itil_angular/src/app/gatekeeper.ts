export class GateKeeper
{
    id;
    name;
    password;
    email;
}