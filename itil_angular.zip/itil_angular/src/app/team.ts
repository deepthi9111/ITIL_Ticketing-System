export class Team
{
    tid;
    name;
    email;
    password;
    specialization;
}