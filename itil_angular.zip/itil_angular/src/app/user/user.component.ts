import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Ticket } from '../ticket';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private userService:UserService) { }

  userid=sessionStorage.getItem('userid');

  tickets:Ticket[];
  submitted=false;

  p:number=1;
  count:number=3;

  ngOnInit(): void 
  {
    this.loadUserIssues();
  }

  loadUserIssues()
  {
    this.tickets=[];
    this.userService.showAllIssues()
    .subscribe(data=>
      {
        console.log(data);
        this.tickets=data;
        this.submitted=true;
      },error=>console.log(error));
  }
}
