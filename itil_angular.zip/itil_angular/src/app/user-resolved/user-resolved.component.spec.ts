import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserResolvedComponent } from './user-resolved.component';

describe('UserResolvedComponent', () => {
  let component: UserResolvedComponent;
  let fixture: ComponentFixture<UserResolvedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserResolvedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserResolvedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
