import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { UserService } from '../user.service';
import { Ticket } from '../ticket';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-resolved',
  templateUrl: './user-resolved.component.html',
  styleUrls: ['./user-resolved.component.css']
})
export class UserResolvedComponent implements OnInit {

  constructor(private userService:UserService,
              private router:Router) { }

  userid=sessionStorage.getItem('userid');

  tickets:Ticket[];
  submitted=false;

  feedback;

  notGiven=true;

  p:number=1;
  count:number=2;

  ngOnInit(): void 
  {
    this.notGiven=true;
    this.loadUResolvedIssues();
  }

  loadUResolvedIssues()
  {
    this.tickets=[];
    this.userService.showUResolvedIssues()
    .subscribe(data=>
      {
        console.log(data);
        this.tickets=data;
        this.submitted=true;
      },error=>console.log(error));
  }

  giveFeedback(ticketid)
  {
    sessionStorage.setItem('ticketid',ticketid);
    this.userService.giveFeedback(this.feedback).subscribe(data=>
      {
        console.log(data);
        this.notGiven=false;
        this.router.navigate(['ulist']);
      })
  }
}
