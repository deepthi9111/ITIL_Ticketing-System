import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ticket } from './ticket';

@Injectable({
  providedIn: 'root'
})
export class UserService {
    
  constructor(private http:HttpClient) { }

  private baseUrl='http://localhost:8080/itil/user';

  userid;

  feedback;

  ticketid;
  
  showAllIssues():Observable<any>
  {
    console.log(this.userid);
    this.userid=sessionStorage.getItem('userid');
    return this.http.get(`${this.baseUrl}/uallissues/${this.userid}`);
  }

  raiseTicket(ticket:Ticket):Observable<any>
  {
    return this.http.post(`${this.baseUrl}/uraise`,ticket);
  }

  showPendingIssues():Observable<any>
  {
    
    this.userid=sessionStorage.getItem('userid');
    console.log("user pending "+this.userid);
    return this.http.get(`${this.baseUrl}/upendingissues/${this.userid}`)
  }

  showUResolvedIssues():Observable<any>
  {
    this.userid=sessionStorage.getItem('userid');
    return this.http.get(`${this.baseUrl}/uresolvedIssues/${this.userid}`);
  }

  giveFeedback(feedback: any):Observable<any>
  {
    this.feedback=feedback;
    this.ticketid=sessionStorage.getItem('ticketid');
    return this.http.put(`${this.baseUrl}/ugivefeedback/${this.ticketid}/${this.feedback}`,this.feedback);
  }
}
