import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { GatekeeperComponent } from './gatekeeper/gatekeeper.component';
import { TeamComponent } from './team/team.component';
import { UserComponent } from './user/user.component';
import { LogoutComponent } from './logout/logout.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { MyProfileComponent } from './my-profile/my-profile.component';
import { AuthguardService } from './authguard.service';
import { GatekeeperPendingComponent } from './gatekeeper-pending/gatekeeper-pending.component';
import { GatekeeperResolvedComponent } from './gatekeeper-resolved/gatekeeper-resolved.component';
import { TeamPendingComponent } from './team-pending/team-pending.component';
import { TeamResolvedComponent } from './team-resolved/team-resolved.component';
import { UserTicketComponent } from './user-ticket/user-ticket.component';
import { UserPendingComponent } from './user-pending/user-pending.component';
import { UserResolvedComponent } from './user-resolved/user-resolved.component';
import { WelcomeComponent } from './welcome/welcome.component';

const routes: Routes = [
  {path:'login', component:LoginComponent},

  {path:'glist', component:GatekeeperComponent, canActivate:[AuthguardService]},
  {path:'gpending', component:GatekeeperPendingComponent, canActivate:[AuthguardService]},
  {path:'gres',component:GatekeeperResolvedComponent, canActivate:[AuthguardService]},

  {path:'tlist', component:TeamComponent, canActivate:[AuthguardService]},
  {path:'tpending', component:TeamPendingComponent, canActivate:[AuthguardService]},
  {path:'tres', component:TeamResolvedComponent, canActivate:[AuthguardService]},

  {path:'uraise', component:UserTicketComponent, canActivate:[AuthguardService]},
  {path:'ulist', component:UserComponent, canActivate:[AuthguardService]},
  {path:'upending', component:UserPendingComponent, canActivate:[AuthguardService]},
  {path:'ures', component:UserResolvedComponent, canActivate:[AuthguardService]},

  {path:'change', component:ChangePasswordComponent,canActivate:[AuthguardService]},
  {path:'profile', component:MyProfileComponent,canActivate:[AuthguardService]},
  {path:'logout', component: LogoutComponent,canActivate:[AuthguardService]},

  {path:'', component:WelcomeComponent, pathMatch:'full',canActivate:[AuthguardService]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
