import { Component, OnInit, ChangeDetectionStrategy, ChangeDetectorRef } from '@angular/core';
import { LoginService } from '../login.service';
import { GateKeeper } from '../gatekeeper';
import { Team } from '../team';
import { User } from '../user';
import { AuthenticationService } from '../authentication.service';
import { Profile } from '../profile';

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class MyProfileComponent implements OnInit 
{

  constructor(private authService: AuthenticationService,
              private cd:ChangeDetectorRef) { }

  gatekeeper:GateKeeper=new GateKeeper();
  team:Team=new Team();
  user:User=new User();

  profile:Profile=new Profile();

  typeofuser;
  userid;
  

  ngOnInit(): void 
  {
    this.showProfile();
  }

  showProfile()
  {
    this.typeofuser=sessionStorage.getItem('typeofuser');
    this.userid=sessionStorage.getItem('userid');

    console.log(this.typeofuser);
    console.log(this.userid);

    this.authService.viewProfile().subscribe(data=>
    {
      
      if(this.typeofuser === 'gatekeeper')
      {
        this.gatekeeper=data;
        console.log(this.gatekeeper);
        this.profile.id=this.gatekeeper.id;
        this.profile.name=this.gatekeeper.name;
        this.profile.email=this.gatekeeper.email;
        console.log(this.profile.id);
        console.log(this.profile.name);
        console.log(this.profile.email);
      }
      else if(this.typeofuser === 'team')
      {
        this.team=data;
        console.log(this.team);
        this.profile.id=this.team.tid;
        this.profile.name=this.team.name;
        this.profile.email=this.team.email;
      }
      else
      {
        this.user=data;
        console.log(this.user);
        this.profile.id=this.user.userid;
        this.profile.name=this.user.name;
        this.profile.email=this.user.email;
      }
      this.cd.markForCheck();
    })
  }

  refresh()
  {
    this.cd.detectChanges();
  }
}
