import { Component, OnInit } from '@angular/core';
import { GatekeeperService } from '../gatekeeper.service';
import { Ticket } from '../ticket';

@Component({
  selector: 'app-gatekeeper',
  templateUrl: './gatekeeper.component.html',
  styleUrls: ['./gatekeeper.component.css']
})
export class GatekeeperComponent implements OnInit {

  constructor(private gatekeeperService: GatekeeperService) { }

  userid=sessionStorage.getItem('userid');

  tickets:Ticket[];
  submitted=false;

  p:number=1;
  count:number=3;

  ngOnInit(): void 
  {
    this.loadGIssues();
  }

  loadGIssues()
  {
    this.tickets=[];
    this.gatekeeperService.showAllIssues()
    .subscribe(data=>
      {
        console.log(data);
        this.tickets=data;
        this.submitted=true;
      },error=>console.log(error));
  }
}
