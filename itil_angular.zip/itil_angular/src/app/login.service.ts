import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Credentials } from './credentials';
import { ChangePassword } from './password';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }

  private baseUrl='http://localhost:8080/itil';

  typeofuser;
  userid;

  checkCredentials(credentials: Credentials):Observable<any>
  {
    return this.http.post(`${this.baseUrl}/login`,credentials);
  }

  changePassword(password:ChangePassword):Observable<any>
  {
    this.typeofuser=sessionStorage.getItem('typeofuser');
    this.userid=sessionStorage.getItem('userid');

    return this.http.put(`${this.baseUrl}/changePassword/${this.userid}/${this.typeofuser}`, password );
  }

  viewProfile():Observable<any>
  {
    this.typeofuser=sessionStorage.getItem('typeofuser');
    this.userid=sessionStorage.getItem('userid');

    console.log(this.userid);
    console.log(this.typeofuser);
    return this.http.get(`${this.baseUrl}/profile/${this.userid}/${this.typeofuser}`);
  }
}
