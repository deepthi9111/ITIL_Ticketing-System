import { Component, OnInit } from '@angular/core';
import { TeamService } from '../team.service';
import { Ticket } from '../ticket';

@Component({
  selector: 'app-team-resolved',
  templateUrl: './team-resolved.component.html',
  styleUrls: ['./team-resolved.component.css']
})
export class TeamResolvedComponent implements OnInit {

  constructor(private teamService:TeamService) { }

  userid=sessionStorage.getItem('userid');

  tickets:Ticket[];
  submitted=false;

  p:number=1;
  count:number=3;

  ngOnInit(): void 
  {
    this.loadTResolvedIssues();
  }

  loadTResolvedIssues()
  {
    this.tickets=[];
    this.teamService.showTResolvedIssues()
    .subscribe(data=>
      {
        console.log(data);
        this.tickets=data;
        this.submitted=true;
      },error=>console.log(error));
  }
}
